const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const scoreEl = document.getElementById("score");

const GROUND_Y = 260;

const player = {
  x: 60,
  y: GROUND_Y,
  width: 30,
  height: 30,
  vy: 0,
  jumping: false
};

const GRAVITY = 0.6;
const JUMP_POWER = -11;

let obstacles = [];
let frame = 0;
let score = 0;
let gameOver = false;
let speed = 4;

function spawnObstacle() {
  obstacles.push({
    x: canvas.width,
    y: GROUND_Y,
    width: 20,
    height: 30
  });
}

function jump() {
  if (!player.jumping && !gameOver) {
    player.vy = JUMP_POWER;
    player.jumping = true;
  }
  if (gameOver) {
    resetGame();
  }
}

function resetGame() {
  obstacles = [];
  frame = 0;
  score = 0;
  speed = 4;
  player.y = GROUND_Y;
  player.vy = 0;
  player.jumping = false;
  gameOver = false;
}

document.addEventListener("keydown", (e) => {
  if (e.code === "Space") {
    e.preventDefault();
    jump();
  }
});
canvas.addEventListener("touchstart", (e) => {
  e.preventDefault();
  jump();
});
canvas.addEventListener("mousedown", jump);

function update() {
  frame++;

  // プレイヤーの物理演算
  player.vy += GRAVITY;
  player.y += player.vy;
  if (player.y > GROUND_Y) {
    player.y = GROUND_Y;
    player.vy = 0;
    player.jumping = false;
  }

  // 障害物の生成
  if (frame % 90 === 0) {
    spawnObstacle();
  }

  // 障害物の移動と当たり判定
  obstacles.forEach((obs) => {
    obs.x -= speed;

    const hit =
      player.x < obs.x + obs.width &&
      player.x + player.width > obs.x &&
      player.y < obs.y + obs.height &&
      player.y + player.height > obs.y;

    if (hit) {
      gameOver = true;
    }
  });

  obstacles = obstacles.filter((obs) => obs.x + obs.width > 0);

  if (!gameOver) {
    score++;
    if (score % 300 === 0) speed += 0.5; // だんだん速くなる
  }

  scoreEl.textContent = "スコア: " + score;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // 地面
  ctx.fillStyle = "#5a3";
  ctx.fillRect(0, GROUND_Y + player.height, canvas.width, 4);

  // プレイヤー
  ctx.fillStyle = "#e33";
  ctx.fillRect(player.x, player.y, player.width, player.height);

  // 障害物
  ctx.fillStyle = "#333";
  obstacles.forEach((obs) => {
    ctx.fillRect(obs.x, obs.y, obs.width, obs.height);
  });

  if (gameOver) {
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#fff";
    ctx.font = "24px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("ゲームオーバー", canvas.width / 2, canvas.height / 2 - 10);
    ctx.font = "16px sans-serif";
    ctx.fillText("クリックかスペースでリスタート", canvas.width / 2, canvas.height / 2 + 20);
  }
}

function loop() {
  if (!gameOver) {
    update();
  }
  draw();
  requestAnimationFrame(loop);
}

loop();
